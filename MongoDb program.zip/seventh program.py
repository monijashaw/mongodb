from pymongo import mongo_client
id=input("enter film id to modify: ")
qr={}
qr["_id"]=id
print(qr)
cty=int(input("enter city: "))
ch={}
ch["city"]=cty
print(ch)
deprt=int(input("enter department: "))
dp={}
dp["department"]=deprt
print(deprt)
upd={"$set":ch}
upd={"$set":deprt}
client=mongo_client("mongodb://localhost:27017")
db=client["workers"]
coll=db["office"]
coll.update_one(qr,upd)
coll.update_one(dp,upd)
print("document updated...")
for doc in coll.find():
    print(doc)
